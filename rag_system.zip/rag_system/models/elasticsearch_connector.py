from elasticsearch import Elasticsearch
import os

# Kết nối Elasticsearch
es = Elasticsearch("http://localhost:9200")

def index_documents(documents):
    # Kiểm tra nếu danh sách documents không rỗng
    if not documents:
        return

    # Lặp qua các tài liệu và index vào Elasticsearch
    for item in documents:
        if isinstance(item, tuple) and len(item) == 2:
            filename, content = item  # Đảm bảo là tuple có 2 phần tử
            # Index tài liệu với trường tên file và nội dung
            es.index(index="documents", id=filename, body={"content": content, "filename": filename})


def search_documents(query):
    # Tìm kiếm trong chỉ mục 'documents'
    response = es.search(index="documents", body={
        "query": {
            "match": {"content": query}
        }
    })

    # Lọc và trả về các tài liệu chứa trường 'filename' và 'content'
    search_results = []
    for hit in response['hits']['hits']:
        if 'filename' in hit['_source'] and 'content' in hit['_source']:
            search_results.append((hit['_source']['filename'], hit['_source']['content']))

    return search_results

def count_occurrences(results, query):
    """Đếm số lần từ khóa xuất hiện trong các tài liệu trả về."""
    occurrences = []
    for filename, content in results:
        count = content.lower().count(query.lower())  # Sử dụng lower() để so sánh không phân biệt chữ hoa chữ thường
        occurrences.append((filename, count))
    return occurrences
