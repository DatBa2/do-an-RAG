# app.py
from models.data_loader import load_text_files
from models.elasticsearch_connector import index_documents, search_documents
from models.index_manager import build_llama_index, load_llama_index
from models.query_engine import query_llama_index, generate_gemini_answer

# Load tài liệu từ thư mục data/documents
documents = load_text_files("models/data/documents")

# Index tài liệu vào Elasticsearch
index_documents(documents)

# Xây dựng chỉ mục LlamaIndex
build_llama_index(documents)

# Tải chỉ mục LlamaIndex
index = load_llama_index()

# Câu hỏi từ người dùng
user_question = "Tóm tắt nội dung"

# Truy vấn LlamaIndex để tìm tài liệu liên quan
retrieved_docs = query_llama_index(index, user_question)

# Ghép ngữ cảnh từ các tài liệu truy xuất được
context = "\n\n".join(retrieved_docs)

# Tạo câu trả lời từ Gemini API
answer = generate_gemini_answer(context, user_question)

# Hiển thị câu trả lời
print("Câu trả lời từ hệ thống:")
print(answer)
